var searchData=
[
  ['tjregion_149',['tjregion',['../structtjregion.html',1,'']]],
  ['tjscalingfactor_150',['tjscalingfactor',['../structtjscalingfactor.html',1,'']]],
  ['tjtransform_151',['tjtransform',['../structtjtransform.html',1,'']]]
];
