#define assert(x) ((void)0)
