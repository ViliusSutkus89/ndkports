#include <openlibm_math.h>

#include "math_private.h"

#ifndef OPENLIBM_ONLY_THREAD_SAFE
int signgam = 0;
#endif
