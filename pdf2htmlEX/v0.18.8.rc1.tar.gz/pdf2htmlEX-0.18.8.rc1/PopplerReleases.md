# pdf2htmlEX and Poppler releases

This table lists the (recent) pdf2htmlEX releases which work for a given
(recent) [poppler](https://poppler.freedesktop.org/) release.

|     poppler    | pdf2htmlEX |
|----------------|------------|
| poppler-0.81.0 | v0.18.7-poppler-0.81.0 |
| poppler-0.80.0 | v0.18.6-poppler-0.80.0 |
| poppler-0.79.0 | v0.18.5-poppler-0.79.0 |
| poppler-0.78.0 | v0.18.4-poppler-0.78.0 |
| poppler-0.77.0 | v0.18.3-poppler-0.77.0 |
| poppler-0.76.0 | v0.18.2-poppler-0.76.0 |
| poppler-0.75.0 | v0.18.1-poppler-0.75.0 |
| poppler-0.74.0 | v0.18.0-poppler-0.74.0-ubuntu-19.04 |
| poppler-0.73.0 | unknown |
| poppler-0.72.0 | unknown |
| poppler-0.71.0 | unknown |
| poppler-0.70.0 | unknown |
| poppler-0.69.0 | unknown |
| poppler-0.68.0 | v0.17.0-poppler-0.68.0-ubuntu-18.10 |
| poppler-0.67.0 | unknown |
| poppler-0.66.0 | unknown |
| poppler-0.65.0 | unknown |
| poppler-0.64.0 | unknown |
| poppler-0.63.0 | unknown |
| poppler-0.62.0 | v0.16.0-poppler-0.62.0-ubuntu-18.04 |


